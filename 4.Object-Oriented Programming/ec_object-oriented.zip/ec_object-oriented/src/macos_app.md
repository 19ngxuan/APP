How to create an app for macOs:
https://stackoverflow.com/questions/1596945/building-osx-app-bundle

How to create an icon file?
https://www.tutonaut.de/anleitung-eigene-icons-am-mac-erstellen-kostenlos/
http://eon.codes/blog/2016/12/06/Creating-an-app-icon/

Basically, even when icon file is available, it may not have the effect to
change the icon. The following web site provides the necessary answer:
https://appletoolbox.com/how-to-change-the-icons-for-your-favorite-apps-on-macos-big-sur/#How_to_change_your_icons_in_macOS_Big_Sur
1. Open the folder where all of your newly-downloaded icons are located.
2. Open the Finder app.
3. Select Applications from the sidebar.
4. Locate the application you wish to change the icon for.
5. Click on the app to highlight it.
6. Press Command + I to reveal the Information Panel.
7. Drag the ICNS file from the icon folder to the small icon in the top right-hand corner of the Information Panel.
8. Enjoy.

Help system:
https://www.fltk.org/doc-1.3/classFl__Help__View.html

ADDENDUM
iconmaker.app produces a icns-file with 1 image only.
Of many online converters, https://www.aconvert.com was
the only one producing an icns-file with a greater number
of images.
